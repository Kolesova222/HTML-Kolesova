<?php
$link = mysqli_connect('localhost', 'f0642801_film', 'film');
mysqli_select_db($link,'f0642801_film');
$query = "INSERT INTO `film` (`id`, `name`, `janr`, `ops`, `rat`) VALUES (NULL, NULL, NULL, NULL, NULL)";
$result = mysqli_query($link,$query);
?>