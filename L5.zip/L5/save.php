<?php
$link = mysqli_connect('localhost', 'f0642801_film', 'film');
mysqli_select_db($link,'f0642801_film');

$tableName = $_POST['table'];
$fieldName = $_POST['field'];
$value = $_POST['value'];
$id = $_POST['id'];

$query = "UPDATE film SET $fieldName = '$value' WHERE id = $id";
$result = mysqli_query($link,$query);
?>