<?php
$link = mysqli_connect('localhost', 'f0642801_film', 'film');
mysqli_select_db($link,'f0642801_film');
$query = 'SELECT * FROM film';
$result = mysqli_query($link,$query);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>ФИЛЬМЫ</title>
	<link rel="stylesheet" href="style.css">
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body style="background: 100% 100% url('https://img.freepik.com/free-vector/seamless-pattern-of-paper-box-with-popcorn_277625-395.jpg');" align="center">
        <div class="film" id="wrap">
        <table align="center" width="100%" cellspacing="1" cellpadding="1" border="1">
            <caption><h1>ФИЛЬМЫ</h1></caption>
					<tr>
					     <th width="20px">№</th>
						  <th width="170px">НАЗВАНИЕ</th>
                          <th width="100px">ЖАНР</th>
                          <th width="500px">ОПИСАНИЕ ФИЛЬМА</th>
                          <th width="20px">РЕЙТИНГ</th>
					</tr>
					<?php
					while ($row = mysqli_fetch_array($result)) {?>
						<tr data-id="<?=$row['id']?>">
							<td height="25" class="id"><?=$row['id']?></td>
							<td height="25" class="edit name"><?=$row['name']?></td>
							<td height="25" class="edit janr"><?=$row['janr']?></td>
							<td height="25" class="edit ops"><?=$row['ops']?></td>
							<td height="25" class="edit rat"><?=$row['rat']?></td>
							
						</tr>
					<?php } ?>
		</table>
	<button class="new">НОВЫЙ ФИЛЬМ</button></div>
<script type="text/javascript" src="js/script.js"></script>
</body>
</html>
<?php
mysqli_free_result($result);
mysqli_close($link);
?>